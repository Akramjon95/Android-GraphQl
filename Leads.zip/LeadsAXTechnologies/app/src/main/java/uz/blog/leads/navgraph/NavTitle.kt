package uz.blog.leads.navgraph

object NavTitle {
    const val HOME = "Home"
    const val CALLS = "Calls"
    const val CHAT = "Chat"
    const val LEADS = "Leads"
    const val MORE = "More"
}