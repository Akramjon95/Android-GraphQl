package uz.blog.leads.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val BgBottomNav = Color(0xFF000000)
val BgSelectedBtn = Color(0xFFE8A889)
val InActiveTextColor = Color(0xff9aa5c4)
val BoxBgColor = Color(0xffF5F5F5)
val statusNew = Color(0xffEEF3FE)
val statusNewText = Color(0xff276EF1)
val statusCustom = Color(0xffF0F9F4)
val statusCustomText = Color(0xff3AA76D)
val textfieldBg = Color(0xffEEEEEE)
val saveBtnColor = Color(0xffe7a889)
val textViewBg = Color(0xFFDDDADA)
val borderBg = Color(0xFFB8B6B6)