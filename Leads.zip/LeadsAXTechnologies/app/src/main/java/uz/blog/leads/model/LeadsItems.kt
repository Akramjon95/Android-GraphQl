package uz.blog.leads.model

data class LeadsItems(
    val name: String,
    val lastName: String,
    val imageRes: String,
    val countryFlag: Int,
    val status: String
)