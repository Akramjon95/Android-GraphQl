package uz.blog.leads.navgraph

import androidx.compose.ui.graphics.vector.ImageVector

open class Item(var path: String, var title: String, var icon: ImageVector)