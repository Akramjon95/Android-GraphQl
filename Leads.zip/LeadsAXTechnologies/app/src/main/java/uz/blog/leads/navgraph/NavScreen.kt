package uz.blog.leads.navgraph

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import uz.blog.leads.screens.CreateLeads
import uz.blog.leads.screens.tabs.LeadsScreen

@Composable
fun NavScreen(){
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "leads" ){
        composable(route = "leads"){
           // LeadsScreen()
        }

        composable(route = "createLeads"){
            CreateLeads(navController)
        }
    }
}