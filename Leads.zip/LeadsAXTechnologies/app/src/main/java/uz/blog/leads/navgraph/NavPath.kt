package uz.blog.leads.navgraph

enum class NavPath {
    HOME, CALLS, CHAT, LEADS, MORE
}